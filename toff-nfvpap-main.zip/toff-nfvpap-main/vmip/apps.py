from django.apps import AppConfig


class VmipConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vmip'
